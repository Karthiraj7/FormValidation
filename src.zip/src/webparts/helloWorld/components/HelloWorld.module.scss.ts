/* tslint:disable */
require("./HelloWorld.module.css");
const styles = {
  helloWorld: 'helloWorld_46f62f73',
  teams: 'teams_46f62f73',
  welcome: 'welcome_46f62f73',
  welcomeImage: 'welcomeImage_46f62f73',
  links: 'links_46f62f73'
};

export default styles;
/* tslint:enable */