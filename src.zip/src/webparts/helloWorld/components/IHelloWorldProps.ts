export interface IHelloWorldProps {
  toggleVisibility?: () => void;
  siteurl:string;
  UserName:string;

  // context: any;
  // items: any[];
}
